FLOATING DASHBOARD BLANK-PAGE HOTFIX
====================================

Problem
-------
The dashboard currently puts the Floating page into rotation according to the
clock even when today's saved floatingAssignments payload is empty. This can
produce an empty Floating page and an empty bottom banner.

What this hotfix changes
------------------------
- Floating only enters dashboard rotation when at least one staff assignment exists.
- The floating rotation banner is hidden when the saved payload is empty.
- Existing current-main styling, outings and Additional Transport code are preserved.
- A backup is created automatically before app/dashboard.tsx is changed.

Apply from the repository root
------------------------------
1. Copy apply-floating-dashboard-blank-hotfix.py into the repository root.
2. Run:

   python apply-floating-dashboard-blank-hotfix.py

3. Review the changes:

   git diff -- app/dashboard.tsx

4. Commit and push:

   git add app/dashboard.tsx
   git commit -m "Fix blank Floating dashboard tab"
   git push origin main

Immediate recovery for today's schedule
---------------------------------------
Open Edit Hub > Floating, confirm the assignments are visible, then click
Save & Exit. Hard-refresh the TV dashboard. The dashboard's normal refresh
cycle should then load the saved assignments.

If assignments are visible in the editor but remain absent after Save & Exit,
check today's B2 schedule row in Supabase: the snapshot must contain a populated
floatingAssignments object for the Sydney date.
